const Footer = () => {
    return (
      <div className="flex justify-center content-center gap-4">
        <h1></h1>
      </div>
    );
  };
  export default Footer;
  