import Footer from "../components/Footer";
import TrelloBoard from "../components/TaskBoard ";

const Home = () => {
  return (
    <div>
      <TrelloBoard />
      <Footer />
    </div>
  );
};
export default Home;
