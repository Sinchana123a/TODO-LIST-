# Setup Instructions

1. Navigate to both the `frontend` and `backend` folders.
2. Install the required dependencies by running:

   ```bash
   npm i
OR
 ```bash
   npm install
AND
   Start the development servers by running:
   npm start


